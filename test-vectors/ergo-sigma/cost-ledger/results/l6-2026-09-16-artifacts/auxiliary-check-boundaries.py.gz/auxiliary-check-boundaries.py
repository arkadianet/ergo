from pathlib import Path
import subprocess,json,sys
sys.path.insert(0,str(Path('scripts/devnet-mixed').resolve()))
from campaign import environment,HERE,WORK,ROOT
cp=str(WORK/'builder-classes')+':'+str(WORK/'campaign-classes')+':'+(ROOT/'scripts/jvm_block_oracle/.work/classpath').read_text().strip()
parents=json.loads((WORK/'warmup-blocks.json').read_text())+[json.loads((WORK/'prefund.json').read_text())]
for stage in ('sum-at-cap','sum-over-cap','single-at-cap','workload'):
 r={'parents':parents,'campaign_stage':stage,'funding':parents[-1]['blockTransactions']['transactions'][0],'workload_index':0,'allow_cost_rejection':stage=='sum-over-cap'}
 req=WORK/('pre-'+stage+'-request.json');req.write_text(json.dumps(r));output=WORK/('pre-'+stage+'.json')
 with (WORK/('pre-'+stage+'.log')).open('w') as log:
  p=subprocess.run(['java','-Xmx2g','-Dlogback.configurationFile='+str(HERE/'logback.xml'),'-cp',cp,'BuildBlock',str(req),str(output)],env=environment(),stdout=log,stderr=subprocess.STDOUT)
 print(stage,p.returncode,Path(str(output)+'.oracle.json').read_text() if p.returncode==0 else 'see log',flush=True)
