import sys,json,time
from pathlib import Path
sys.path.insert(0,str(Path('scripts/devnet-mixed').resolve()))
from smoke import api,tips,wait_for
blocks=json.load(open('scripts/devnet-mixed/.work/warmup-blocks.json'))
out=Path('scripts/devnet-mixed/.work/warmup-observations.json')
records=[]
for n in ('scala','rust'):
 i=api(n,'/info'); assert i['parameters']['maxBlockCost']==37509,(n,i); assert not i['fullHeight']
try:
 for b in blocks:
  h=b['header']['height']; before={n:api(n,'/info') for n in ('scala','rust')}
  responses={n:api(n,'/blocks',b) for n in ('scala','rust')}
  try: after=wait_for(lambda:tips(h),f'warmup {h}',timeout=15)
  except BaseException:
   records.append({'height':h,'before':before,'responses':responses,'after':{n:api(n,'/info') for n in ('scala','rust')},'failed':True}); raise
  records.append({'height':h,'block_id':b['header']['id'],'observations':{n:{k:i[k] for k in ('fullHeight','bestFullHeaderId','stateRoot')} for n,i in after.items()}})
  if h%25==0: print(h,flush=True)
finally: out.write_text(json.dumps(records,indent=2)+'\n')
