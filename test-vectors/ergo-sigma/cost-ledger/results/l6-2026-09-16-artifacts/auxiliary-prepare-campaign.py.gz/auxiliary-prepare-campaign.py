from pathlib import Path
import subprocess,json,os
h=Path('scripts/devnet-mixed').resolve(); w=h/'.work'; root=h.parent.parent
cp=(root/'scripts/jvm_block_oracle/.work/classpath').read_text().strip()
campaign_cp=str(w/'campaign-classes')+':'+cp
s=(h/'scala-node.conf').read_text().replace('include "genesis.conf"',f'include "{h}/genesis.conf"').replace('.work/scala"','.work/campaign-scala"')
(w/'campaign-scala-node.conf').write_text(s)
s=(h/'rust-node.toml').read_text().replace('.work/rust"','.work/campaign-rust"')+'\n[chain]\ndevnet_max_block_cost = 37509\n'
(w/'campaign-rust-node.toml').write_text(s)
env=os.environ | {'SCALA_CONFIG':str(w/'campaign-scala-node.conf'),'RUST_CONFIG':str(w/'campaign-rust-node.toml'),'CAMPAIGN_CLASSPATH':str(w/'campaign-classes')}
with (w/'builder-compile.log').open('w') as log:
 subprocess.run(['scala-cli','compile',str(h/'BuildBlock.scala'),'--server=false','--suppress-outdated-dependency-warning','--scala','2.12.20','--classpath',campaign_cp,'-d',str(w/'builder-classes')],stdout=log,stderr=subprocess.STDOUT,check=True)
(w/'warmup-request.json').write_text(json.dumps({'parents':[],'transactions':[],'count':720}))
with (w/'warmup-build.log').open('w') as log:
 subprocess.run(['java','-Xmx2g','-Dlogback.configurationFile='+str(h/'logback.xml'),'-cp',str(w/'builder-classes')+':'+campaign_cp,'BuildBlock',str(w/'warmup-request.json'),str(w/'warmup-blocks.json')],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
subprocess.run([str(h/'start.sh')],env=env,check=True)
