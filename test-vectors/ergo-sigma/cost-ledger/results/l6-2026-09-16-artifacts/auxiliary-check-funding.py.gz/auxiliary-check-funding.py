from pathlib import Path
import subprocess,json,sys
sys.path.insert(0,str(Path('scripts/devnet-mixed').resolve()))
from campaign import select_workload,environment,HERE,WORK,ROOT
cp=str(WORK/'campaign-classes')+':'+(ROOT/'scripts/jvm_block_oracle/.work/classpath').read_text().strip()
with (WORK/'builder-compile.log').open('w') as log:
 subprocess.run(['scala-cli','compile',str(HERE/'BuildBlock.scala'),str(HERE/'CampaignTransactions.scala'),'--server=false','--suppress-outdated-dependency-warning','--scala','2.12.20','--classpath',cp,'-d',str(WORK/'builder-classes')],stdout=log,stderr=subprocess.STDOUT,check=True)
request={'parents':json.loads((WORK/'warmup-blocks.json').read_text()),'campaign_stage':'fund','workload_trees':[i['tree_hex'] for i in select_workload()]}
(WORK/'prefund-request.json').write_text(json.dumps(request))
with (WORK/'prefund-build.log').open('w') as log:
 subprocess.run(['java','-Xmx2g','-Dlogback.configurationFile='+str(HERE/'logback.xml'),'-cp',str(WORK/'builder-classes')+':'+cp,'BuildBlock',str(WORK/'prefund-request.json'),str(WORK/'prefund.json')],env=environment(),stdout=log,stderr=subprocess.STDOUT,check=True)
print((WORK/'prefund.json.oracle.json').read_text())
